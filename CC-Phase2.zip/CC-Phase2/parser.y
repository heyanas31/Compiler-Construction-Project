%{
#include <stdio.h>
#include <stdlib.h>

extern int yylex();
extern int yylineno;
extern char *yytext;  // Current lexeme from Flex

void yyerror(const char *s);
%}

%token AGR WRNA BARBAR DEDO RUKO
%token RAKAM ASHARIYA LAFZ KHALI
%token LIKHO LAINA
%token DAROST GALAT
%token ADD SUBTRACT MULT DIV
%token AND OR NOT
%token ID
%token INT FLOAT CHAR STRING

%token EQ ASSIGN GT LT
%token LPAREN RPAREN LBRACE RBRACE
%token SEMICOLON COMMA

%left OR
%left AND
%left EQ GT LT
%left ADD SUBTRACT
%left MULT DIV
%right NOT

%%

program
    : KHALI ID LPAREN RPAREN compound_stmt
    ;

compound_stmt
    : LBRACE stmt_list RBRACE
    ;

stmt_list
    : stmt_list statement
    | /* empty */
    ;

statement
    : declaration
    | assignment
    | if_stmt
    | for_stmt
    | io_stmt
    | return_stmt
    | break_stmt
    ;

declaration
    : type ID SEMICOLON
    | type ID ASSIGN expression SEMICOLON
    ;

type
    : RAKAM
    | ASHARIYA
    | LAFZ
    ;

assignment
    : ID ASSIGN expression SEMICOLON
    ;

if_stmt
    : AGR LPAREN condition RPAREN compound_stmt
    | AGR LPAREN condition RPAREN compound_stmt WRNA compound_stmt
    ;

for_stmt
    : BARBAR LPAREN for_init SEMICOLON for_cond SEMICOLON for_update RPAREN compound_stmt
    ;

for_init
    : type ID ASSIGN expression
    | type ID
    | ID ASSIGN expression
    | /* empty */
    ;

for_cond
    : condition
    | /* empty */
    ;

for_update
    : ID ASSIGN expression
    | ID ASSIGN expression ADD expression
    | ID ASSIGN expression SUBTRACT expression
    | /* empty */
    ;

io_stmt
    : LIKHO LPAREN STRING RPAREN SEMICOLON
    | LIKHO LPAREN expression RPAREN SEMICOLON
    | LAINA LPAREN ID RPAREN SEMICOLON
    ;

return_stmt
    : DEDO expression SEMICOLON
    ;

break_stmt
    : RUKO SEMICOLON
    ;

condition
    : expression relational_op expression
    ;

relational_op
    : GT
    | LT
    | EQ
    ;

expression
    : expression ADD expression
    | expression SUBTRACT expression
    | expression MULT expression
    | expression DIV expression
    | LPAREN expression RPAREN
    | value
    | ID
    ;

value
    : INT
    | FLOAT
    | CHAR
    | DAROST
    | GALAT
    ;

%%

void yyerror(const char *s)
{
    // Show the actual lexeme causing the syntax error
    printf("Syntax Error at line %d: %s\n", yylineno, yytext);
}

int main()
{
    if (yyparse() == 0) {
        printf("\nParsing completed successfully.\n");
    }
    return 0;
}